# Exercise - in Class Activity 4

## Use the <i>scatter_plot</i> function in the Single_View and Two_View examples 

1. Come up with a new scatter plot function that just received data and labels to generate scatter plot
2. Create a four view (grid) visualization
3. Use bootstrap framework or html/table create a grid
4. The final result should look like the sample file
5. <b>Make a webpage on GitHub and submit the link in myCourses.</b>

<img src="https://raw.githubusercontent.com/umassdgithub/Fall2021-Week10-MultiView-part-1/main/Four_View/Scatter_4View.png?token=AQZIPUZ2NJMVGGH67VTJZDTBQKRCK"/>

 
